"""app.py —— Streamlit 情感分析界面（仅 UI 层）

本文件只负责界面渲染。模型加载、文本清洗、预测等逻辑全在 emotion_engine.py 中。
UI 同学改这个文件，引擎同学改 emotion_engine.py，互不冲突。
"""

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib
import altair as alt
from datetime import datetime
import random

# ---- 从共享引擎导入所有业务逻辑 ----
from emotion_engine import (
    clean_text,
    predict,
    EMOTION_CONFIG,
    load_models,
    LABEL_TO_CN,
)

# =============================================================================
# 页面配置
# =============================================================================
st.set_page_config(
    page_title="中文情感分析",
    page_icon="😊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# =============================================================================
# 常量
# =============================================================================
EXAMPLE_TEXTS = [
    {"text": "今天收到了期待已久的录取通知书，全家人都为我感到骄傲！", "emotion": "开心"},
    {"text": "深夜独自走在空无一人的小巷里，总觉得身后有什么东西跟着我。", "emotion": "恐惧"},
    {"text": "辛苦准备了三个月的项目被领导一句话否定了，心里说不出的委屈。",  "emotion": "悲伤"},
    {"text": "这个服务态度实在太差了，等了半小时连杯水都没有！",               "emotion": "愤怒"},
    {"text": "刚才在路上居然遇到了十年没见的小学同学，真是太巧了！",           "emotion": "惊讶"},
    {"text": "今天天气不错，我打算去超市买点菜回来做晚饭。",                   "emotion": "中性"},
]

MAX_HISTORY = 50
MAX_CHARS = 500

# =============================================================================
# CSS
# =============================================================================
def inject_css():
    st.markdown("""
    <style>
    .stApp { background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); }
    .main .block-container { background: rgba(30,41,59,0.6); border-radius: 16px; padding: 2rem; }

    h1,h2,h3,h4,h5,h6 { color: #f1f5f9 !important; }
    p,span,label,div { color: #cbd5e1; }

    [data-testid="stSidebar"] { background: linear-gradient(180deg, #0f172a 0%, #1e293b 100%); }
    [data-testid="stSidebar"] h1, [data-testid="stSidebar"] h2,
    [data-testid="stSidebar"] h3, [data-testid="stSidebar"] h4 { color: #f1f5f9 !important; }
    [data-testid="stSidebar"] p, [data-testid="stSidebar"] span,
    [data-testid="stSidebar"] label { color: #94a3b8; }

    textarea {
        background: #1e293b !important; border: 2px solid #334155 !important;
        border-radius: 12px !important; color: #f1f5f9 !important;
        font-size: 15px !important; padding: 16px !important;
        transition: border-color 0.3s ease;
    }
    textarea:focus { border-color: #3B82F6 !important; box-shadow: 0 0 0 3px rgba(59,130,246,0.2) !important; }
    textarea::placeholder { color: #64748b !important; }

    .stButton > button { border-radius: 10px !important; font-weight: 600 !important; transition: all 0.3s ease !important; border: none !important; font-size: 15px !important; }
    .stButton > button[kind="primary"] { background: linear-gradient(135deg, #3B82F6, #2563EB) !important; color: white !important; padding: 0.7rem 2rem !important; }
    .stButton > button[kind="primary"]:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(59,130,246,0.4); }
    .stButton > button[kind="secondary"] { background: #334155 !important; color: #cbd5e1 !important; }
    .stButton > button[kind="secondary"]:hover { background: #475569 !important; color: #f1f5f9 !important; }
    .stButton > button:disabled { opacity: 0.4 !important; cursor: not-allowed !important; }

    .main .stButton > button { background: rgba(30,41,59,0.8) !important; border: 1px solid #334155 !important; color: #cbd5e1 !important; white-space: pre-line !important; line-height: 1.5 !important; padding: 14px 12px !important; text-align: center !important; font-size: 13px !important; }
    .main .stButton > button:hover { border-color: #3B82F6 !important; background: rgba(30,41,59,0.95) !important; transform: translateY(-2px); box-shadow: 0 8px 25px rgba(59,130,246,0.15); }
    .main .stButton > button[kind="primary"] { background: linear-gradient(135deg, #3B82F6, #2563EB) !important; border: none !important; color: white !important; font-size: 15px !important; white-space: nowrap !important; text-align: center !important; padding: 0.7rem 2rem !important; }
    .main .stButton > button[kind="primary"]:hover { box-shadow: 0 8px 25px rgba(59,130,246,0.4); }

    [data-testid="stSidebar"] .stButton > button { background: rgba(30,41,59,0.4) !important; border: 1px solid #334155 !important; color: #94a3b8 !important; text-align: left !important; font-size: 12px !important; padding: 8px 10px !important; white-space: nowrap !important; overflow: hidden !important; text-overflow: ellipsis !important; line-height: 1.3 !important; }
    [data-testid="stSidebar"] .stButton > button:hover { border-color: #3B82F6 !important; background: rgba(30,41,59,0.8) !important; color: #cbd5e1 !important; }

    .emotion-big-card { background: rgba(30,41,59,0.8); border: 2px solid #334155; border-radius: 20px; padding: 40px 30px; text-align: center; margin: 20px 0; backdrop-filter: blur(10px); }
    .emotion-emoji { font-size: 64px; line-height: 1.2; }
    .emotion-name { font-size: 42px; font-weight: 800; margin: 12px 0 4px 0; }
    .emotion-confidence { font-size: 22px; font-weight: 600; margin-bottom: 20px; }
    .confidence-bar-bg { background: #334155; border-radius: 10px; height: 10px; overflow: hidden; margin: 0 auto; max-width: 300px; }
    .confidence-bar-fill { height: 100%; border-radius: 10px; transition: width 0.8s cubic-bezier(0.22,0.61,0.36,1); }

    .prob-bar-container { margin: 16px 0; }
    .prob-bar-row { display: flex; align-items: center; margin-bottom: 10px; }
    .prob-bar-label { width: 70px; font-size: 15px; font-weight: 600; text-align: right; padding-right: 12px; flex-shrink: 0; }
    .prob-bar-track { flex: 1; background: #1e293b; border-radius: 8px; height: 28px; overflow: hidden; position: relative; }
    .prob-bar-fill { height: 100%; border-radius: 8px; transition: width 1s cubic-bezier(0.22,0.61,0.36,1); display: flex; align-items: center; padding-left: 12px; }
    .prob-bar-value { color: #fff; font-size: 13px; font-weight: 700; white-space: nowrap; }

    .low-confidence-warning { background: rgba(245,158,11,0.15); border: 1px solid rgba(245,158,11,0.4); border-radius: 10px; padding: 12px 20px; margin: 16px 0; display: flex; align-items: center; gap: 10px; font-size: 14px; color: #FCD34D; }

    .char-count { text-align: right; font-size: 12px; color: #64748b; margin-top: 4px; }
    .char-count.over-limit { color: #EF4444; }

    .history-badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; }

    [data-testid="stExpander"] { background: transparent !important; border: 1px solid #334155 !important; border-radius: 12px !important; }
    [data-testid="stExpander"] details summary { color: #cbd5e1 !important; }
    .stCheckbox label { color: #94a3b8 !important; }
    [data-testid="stMetricValue"] { color: #f1f5f9 !important; }
    [data-testid="stMetricLabel"] { color: #94a3b8 !important; }
    .stAlert { background: rgba(30,41,59,0.8) !important; border-radius: 10px !important; border: 1px solid #334155 !important; }

    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: #1e293b; border-radius: 3px; }
    ::-webkit-scrollbar-thumb { background: #475569; border-radius: 3px; }
    ::-webkit-scrollbar-thumb:hover { background: #64748b; }
    </style>
    """, unsafe_allow_html=True)


# =============================================================================
# Session State
# =============================================================================
if "history" not in st.session_state:
    st.session_state.history = []
if "input_area" not in st.session_state:
    st.session_state.input_area = ""
if "analyze_triggered" not in st.session_state:
    st.session_state.analyze_triggered = False


def add_to_history(text: str, emotion: str, confidence: float, probs: dict):
    record = {
        "text": text,
        "emotion": emotion,
        "confidence": confidence,
        "probs": dict(probs),
        "time": datetime.now().strftime("%H:%M:%S"),
    }
    st.session_state.history.insert(0, record)
    if len(st.session_state.history) > MAX_HISTORY:
        st.session_state.history = st.session_state.history[:MAX_HISTORY]


# =============================================================================
# 初始化（模型加载用 Streamlit 缓存）
# =============================================================================
@st.cache_resource
def load_models_cached():
    return load_models()

model, vectorizer, classes_cn = load_models_cached()
inject_css()

# =============================================================================
# 侧边栏
# =============================================================================
with st.sidebar:
    st.markdown("""
    <div style="text-align:center; padding: 16px 0 8px 0;">
        <div style="font-size:48px;">😊</div>
        <h2 style="margin:8px 0 4px 0; color:#f1f5f9;">情感分析系统</h2>
        <p style="font-size:13px; color:#64748b; margin:0;">AI-powered Sentiment Analysis</p>
    </div>
    """, unsafe_allow_html=True)
    st.divider()

    st.markdown('<p style="font-size:12px; text-transform:uppercase; letter-spacing:1px; color:#64748b; margin-bottom:8px;">显示设置</p>', unsafe_allow_html=True)
    show_detail = st.checkbox("显示详细概率分布", value=True)
    show_charts = st.checkbox("显示统计图表", value=True)
    st.divider()

    with st.expander("模型信息", expanded=False):
        st.markdown(f"""
        <div style="font-size:13px; line-height:1.8;">
            <p><b>算法：</b>TF-IDF + 逻辑回归</p>
            <p><b>支持情感：</b>6 种</p>
            <p><b>情感类别：</b>开心 / 愤怒 / 悲伤 / 恐惧 / 惊讶 / 中性</p>
            <p><b>分词引擎：</b>jieba</p>
        </div>
        """, unsafe_allow_html=True)
    st.divider()

    st.markdown('<p style="font-size:12px; text-transform:uppercase; letter-spacing:1px; color:#64748b; margin-bottom:8px;">分析历史（最近10条）</p>', unsafe_allow_html=True)

    if st.session_state.history:
        for i, rec in enumerate(st.session_state.history[:10]):
            cfg = EMOTION_CONFIG.get(rec["emotion"], EMOTION_CONFIG["中性"])
            truncated = rec["text"][:25] + ("..." if len(rec["text"]) > 25 else "")
            btn_label = f"{rec['time']} | {truncated} | {cfg['emoji']} {rec['emotion']} {rec['confidence']:.0%}"
            if st.button(btn_label, key=f"history_{i}_{rec['time']}", use_container_width=True):
                st.session_state.input_area = rec["text"]
                st.session_state.analyze_triggered = False
                st.rerun()
            st.markdown(f"""
            <div style="margin-top:-12px; margin-bottom:4px;">
                <span class="history-badge" style="background:{cfg['light']}; color:{cfg['color']}; font-size:11px;">
                    {cfg['emoji']} {rec['emotion']} · {rec['confidence']:.0%}
                </span>
            </div>
            """, unsafe_allow_html=True)

        if len(st.session_state.history) > 10:
            st.caption(f"... 还有 {len(st.session_state.history) - 10} 条历史记录")
        if st.button("清空历史", key="clear_history", use_container_width=True):
            st.session_state.history = []
            st.rerun()
    else:
        st.markdown('<div style="text-align:center; padding:20px 0; color:#64748b; font-size:13px;">📭 暂无分析记录<br/>输入文本开始分析吧</div>', unsafe_allow_html=True)

    st.divider()
    st.markdown('<div style="text-align:center; font-size:11px; color:#475569;">人基大作业 · 中文情感分析<br/>Powered by Streamlit & scikit-learn</div>', unsafe_allow_html=True)

# =============================================================================
# 主内容区
# =============================================================================
st.markdown("""
<div style="text-align:center; margin-bottom: 30px;">
    <h1 style="font-size: 40px; font-weight: 800; margin-bottom: 4px; color: #f1f5f9;">😊 中文文本情感分析</h1>
    <p style="font-size: 15px; color: #64748b; margin: 0;">输入一段中文文本，AI 自动识别其中蕴含的情感</p>
</div>
""", unsafe_allow_html=True)

# ---- 输入区 ----
input_col1, input_col2 = st.columns([6, 1])
with input_col1:
    user_input = st.text_area(
        label="输入要分析的中文文本",
        placeholder="在这里输入你想分析的中文文本，例如：\"今天心情特别好，阳光明媚，感觉整个世界都在微笑！\"",
        height=120,
        key="input_area",
        label_visibility="collapsed",
    )
with input_col2:
    st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)
    if st.button("🎲 填充示例", use_container_width=True, key="random_example"):
        example = random.choice(EXAMPLE_TEXTS)
        st.session_state.input_area = example["text"]
        st.session_state.analyze_triggered = False
        st.rerun()

# ---- 字符计数 ----
char_len = len(user_input) if user_input else 0
over_class = " over-limit" if char_len > MAX_CHARS else ""
st.markdown(f'<div class="char-count{over_class}">{char_len}/{MAX_CHARS}</div>', unsafe_allow_html=True)

# ---- 按钮区 ----
btn_col1, btn_col2, _ = st.columns([2, 1, 1])
with btn_col1:
    analyze_disabled = not (user_input and user_input.strip())
    if st.button("🔍 分析情感", type="primary", use_container_width=True,
                 disabled=analyze_disabled, key="analyze_btn"):
        st.session_state.analyze_triggered = True
        st.rerun()
with btn_col2:
    if st.button("🗑️ 清空", use_container_width=True, key="clear_btn"):
        st.session_state.input_area = ""
        st.session_state.analyze_triggered = False
        st.rerun()

if analyze_disabled:
    st.caption("👆 输入文本后即可开始分析")

st.divider()

# =============================================================================
# 分析结果
# =============================================================================
if st.session_state.analyze_triggered and user_input and user_input.strip():
    with st.spinner("🧠 AI 正在分析情感..."):
        emotion, probs = predict(user_input)

    if emotion is None:
        st.warning("⚠️ 清洗后文本为空，请尝试输入更丰富的中文内容。")
    else:
        confidence = max(probs.values())
        cfg = EMOTION_CONFIG.get(emotion, EMOTION_CONFIG["中性"])

        # 情感大卡片
        st.markdown(f"""
        <div class="emotion-big-card">
            <div class="emotion-emoji">{cfg['emoji']}</div>
            <div class="emotion-name" style="color:{cfg['color']};">{emotion}</div>
            <div class="emotion-confidence" style="color:{cfg['color']};">置信度 {confidence:.1%}</div>
            <div class="confidence-bar-bg">
                <div class="confidence-bar-fill" style="width:{confidence*100}%; background:{cfg['color']};"></div>
            </div>
        </div>
        """, unsafe_allow_html=True)

        if confidence < 0.6:
            st.markdown('<div class="low-confidence-warning"><span style="font-size:20px;">⚠️</span><span>置信度较低（< 60%），模型对此文本的情感判断可能不够确定。</span></div>', unsafe_allow_html=True)

        # 概率分布条形图
        if show_detail:
            st.markdown('<h4 style="color:#f1f5f9; margin-top:24px;">📊 情感概率分布</h4>', unsafe_allow_html=True)
            sorted_probs = sorted(probs.items(), key=lambda x: x[1], reverse=True)
            html_bars = '<div class="prob-bar-container">'
            for emo, prob in sorted_probs:
                ecfg = EMOTION_CONFIG.get(emo, EMOTION_CONFIG["中性"])
                pct = prob * 100
                if pct < 8:
                    html_bars += f"""
                    <div class="prob-bar-row">
                        <div class="prob-bar-label" style="color:{ecfg['color']};">{ecfg['emoji']} {emo}</div>
                        <div class="prob-bar-track"><div class="prob-bar-fill" style="width:{pct}%; background:{ecfg['color']};"></div></div>
                        <span style="width:50px; text-align:left; font-size:13px; font-weight:600; color:{ecfg['color']}; padding-left:10px;">{prob:.1%}</span>
                    </div>"""
                else:
                    html_bars += f"""
                    <div class="prob-bar-row">
                        <div class="prob-bar-label" style="color:{ecfg['color']};">{ecfg['emoji']} {emo}</div>
                        <div class="prob-bar-track">
                            <div class="prob-bar-fill" style="width:{pct}%; background:{ecfg['color']};"><span class="prob-bar-value">{prob:.1%}</span></div>
                        </div>
                    </div>"""
            html_bars += '</div>'
            st.markdown(html_bars, unsafe_allow_html=True)

        # 统计图表
        if show_charts:
            with st.expander("📈 统计图表", expanded=False):
                tab1, tab2 = st.tabs(["柱状图", "饼图"])
                with tab1:
                    df_chart = pd.DataFrame(
                        [{"情感": k, "概率": v} for k, v in sorted(probs.items(), key=lambda x: x[1], reverse=True)])
                    df_chart["颜色"] = df_chart["情感"].map(lambda e: EMOTION_CONFIG.get(e, EMOTION_CONFIG["中性"])["color"])
                    bar_chart = (
                        alt.Chart(df_chart)
                        .mark_bar(cornerRadiusTopLeft=6, cornerRadiusTopRight=6)
                        .encode(
                            x=alt.X("概率:Q", axis=alt.Axis(format="%", title="概率"), scale=alt.Scale(domain=[0, 1])),
                            y=alt.Y("情感:N", sort="-x", title=None, axis=alt.Axis(labelFontSize=14)),
                            color=alt.Color("情感:N", scale=alt.Scale(domain=list(df_chart["情感"]), range=list(df_chart["颜色"])), legend=None),
                            tooltip=["情感", alt.Tooltip("概率:Q", format=".2%")],
                        )
                        .properties(height=250)
                        .configure_view(strokeWidth=0)
                        .configure_axis(gridColor="#334155", domainColor="#334155", labelColor="#94a3b8", titleColor="#94a3b8")
                    )
                    st.altair_chart(bar_chart, use_container_width=True)
                with tab2:
                    matplotlib.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans']
                    matplotlib.rcParams['axes.unicode_minus'] = False
                    pie_data = {k: v for k, v in probs.items() if v >= 0.001}
                    labels = list(pie_data.keys())
                    sizes = list(pie_data.values())
                    colors = [EMOTION_CONFIG.get(l, EMOTION_CONFIG["中性"])["color"] for l in labels]
                    fig, ax = plt.subplots(figsize=(6, 6))
                    fig.patch.set_facecolor('none')
                    ax.set_facecolor('none')
                    wedges, texts, autotexts = ax.pie(
                        sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90,
                        textprops={'fontsize': 12, 'color': '#cbd5e1'},
                        wedgeprops={'linewidth': 1.5, 'edgecolor': '#0f172a'}, pctdistance=0.82)
                    for at in autotexts:
                        at.set_color('#f1f5f9')
                        at.set_fontweight('bold')
                    ax.set_title("情感概率分布", fontsize=14, color='#f1f5f9', pad=20, fontweight='bold')
                    st.pyplot(fig)

        # 存入历史
        already_in = any(h["text"] == user_input for h in st.session_state.history)
        if not already_in:
            add_to_history(user_input, emotion, confidence, probs)
        st.session_state.analyze_triggered = False

# =============================================================================
# 空状态示例卡片
# =============================================================================
elif not st.session_state.analyze_triggered:
    st.markdown('<div style="text-align:center; margin: 20px 0 16px 0;"><p style="font-size:16px; color:#94a3b8;">💡 不知道该输入什么？试试下面的示例：</p></div>', unsafe_allow_html=True)
    cols = st.columns(3)
    for i, example in enumerate(EXAMPLE_TEXTS[:6]):
        cfg = EMOTION_CONFIG.get(example["emotion"], EMOTION_CONFIG["中性"])
        truncated = example["text"][:35] + ("..." if len(example["text"]) > 35 else "")
        with cols[i % 3]:
            if st.button(f"{cfg['emoji']} {example['emotion']}\n{truncated}", key=f"example_card_{i}", use_container_width=True):
                st.session_state.input_area = example["text"]
                st.session_state.analyze_triggered = False
                st.rerun()
